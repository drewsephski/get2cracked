interface HeaderSectionProps {
  label?: string;
  title: string;
  subtitle?: string;
  description?: string;
}

export function HeaderSection({ label, title, subtitle, description }: HeaderSectionProps) {
  return (
    <div className="flex flex-col items-center text-center">
      {label ? (
        <div className="text-gradient_blue mb-4 font-semibold">
          {label}
        </div>
      ) : null}
      <h2 className="font-heading text-3xl md:text-4xl lg:text-[40px]">
        {title}
      </h2>
      {subtitle ? (
        <p className="mt-6 text-balance text-lg text-muted-foreground">
          {subtitle}
        </p>
      ) : null}
      {description ? (
        <p className="mt-4 max-w-2xl text-balance text-base text-muted-foreground">
          {description}
        </p>
      ) : null}
    </div>
  );
}
