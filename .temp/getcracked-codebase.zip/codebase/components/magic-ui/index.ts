// components/magic-ui/index.ts
export * from './magic-card'
export * from './orbiting-circles'
export * from './sparkles-text'
export * from './animated-gradient-text'
export * from './magic-demo'