import { redirect } from "next/navigation";

import { getCurrentUser } from "@/lib/session";
import { getUserSubscriptionPlan } from "@/lib/subscription";
import { constructMetadata } from "@/lib/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { DashboardHeader } from "@/components/dashboard/header";
import { BillingInfo } from "@/components/pricing/billing-info";
import { Icons } from "@/components/shared/icons";
import { pricingData } from "@/config/subscriptions";

export const metadata = constructMetadata({
  title: "Billing – SaaS Starter",
  description: "Manage billing and your subscription plan.",
});

export default async function BillingPage() {
  console.log("--- Rendering Billing Page ---");
  const user = await getCurrentUser();

  if (!user?.id) {
    redirect("/sign-in");
  }

  let userSubscriptionPlan;
  if (user.role === "USER") {
    userSubscriptionPlan = await getUserSubscriptionPlan(user.id);
  }

  // Use the free plan as default if no subscription plan found
  const subscriptionPlan = userSubscriptionPlan || {
    ...pricingData[0], // Starter (free) plan
    isPaid: false,
    interval: null,
    isCanceled: false,
    stripeCustomerId: null,
    stripeSubscriptionId: null,
    stripePriceId: null,
    stripeCurrentPeriodEnd: null,
    credits: 3, // Default credits for free users
  };

  return (
    <>
      <DashboardHeader
        heading="Billing"
        text="Manage billing and your subscription plan."
      />
      <div className="grid gap-8">
        <BillingInfo userSubscriptionPlan={subscriptionPlan} />
      </div>
    </>
  );
}
